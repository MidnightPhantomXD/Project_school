package org.example.entity;

import org.example.projectile.Projectile;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Entity {
    protected Coordinates coord;
    protected int width;
    protected int height;
    public BufferedImage down1, down2, down3, down4, up1, up2, up3, up4, left1, left2, left3, left4, right1, right2, right3, right4;
    public String direction;
    public int spriteCounter = 0;
    public int spriteNum = 1;
    public Rectangle solidArea;
    public boolean collisionOn = false;
    public int speed;
    public Projectile projectile;

    public Entity(int x, int y) {
        this.coord = new Coordinates(x,y);
        this.direction = "down";
    }
    public Coordinates getCoord() {
        return coord;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }


    public int getX() {
        return coord.x;
    }

    public void setX(int x) {
        this.coord.x = x;
    }

    public int getY() {
        return coord.y;
    }

    public void setY(int y) {
        this.coord.y = y;
    }
}