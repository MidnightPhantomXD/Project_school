package org.example.tile_interactive;

import org.example.GameGraphics;
import org.example.Logic;
import org.example.tile.Tile;

public class IT_Shelf extends InteractiveTile{
    public IT_Shelf(GameGraphics graphic,int row, int col){
        super(row, col);
        this.x = graphic.tileFin * (col - 1);
        this.y = graphic.tileFin * (row - 1);

        Tile shelf = new Tile();
        shelf.collision = true;
        interactive = true;
    }
}
