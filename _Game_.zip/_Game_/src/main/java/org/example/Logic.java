package org.example;

import org.example.entity.Enemy;
import org.example.entity.Entity;
import org.example.entity.Player;
import org.example.projectile.Projectile;
import org.example.tile.CollisionCheck;
import org.example.tile_interactive.InteractiveTile;
import org.example.tile.TileCheck;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class Logic {
    Player player;
    Panel panel;
    GameGraphics graphic;
    CollisionCheck cCheck;
    TileCheck tileCheck;
    InteractiveTile[] iTile = new InteractiveTile[12];
    InteractiveTile[] weapon = new InteractiveTile[52];
    AssetSetter AS;
    public int point = 0; //question mark tiles
    public int weaponCount = 0;
    public ArrayList<Entity> entities;
    public ArrayList<Entity> projectileList;
    public static final long SHOOT_COOLDOWN = 500;
    public long lastShootTime = 0;
    public int gameState;
    public final int menu = 0;
    public final int play = 1;
    public final int tutorial = 2;
    public final int end = 3;
    public final int lvl = 4;
    public String message = "";
    public boolean messageOn = false;
    public int counter = 0; //counting things (message, lvl screen)
    public int randomMessage = 0;
    public int randomNumber;
    public int level = 1;
    Sound sound;
    public static final String currentLevel = "text/level.txt";


    public Logic(Panel panel) {
        this.panel = panel;
        this.graphic = new GameGraphics(this);
        this.tileCheck = new TileCheck(graphic);
        this.cCheck = new CollisionCheck(graphic, tileCheck);
        this.sound = new Sound();
        this.player = new Player(8 * graphic.tileFin, 6 * graphic.tileFin, graphic);
        this.entities = new ArrayList<>();
        this.entities.add(player);
        this.projectileList = new ArrayList<>();

    }

    public Player getPlayer(){
        return player;
    }
    public void setGraphics(GameGraphics graphics) {
        this.graphic = graphics;
    }
    public void setUpGame() throws IOException {
        gameState = 0;

        AS.setITile();
        AS.spawnWeapon();
    }

    public void initialize(){

        AS = new AssetSetter(this, graphic);
        if (gameState == play){

            if (graphic.currentMap == 0){

                if (point > 0){

                    switch (point){
                        case 1:
                            //SECTOR D
                            Enemy spider1 = new Enemy(graphic.tileFin * 8, graphic.tileFin * 38, 30);
                            entities.add(spider1);
                            notification("Enemy spawned");

                            Enemy spider0 = new Enemy(graphic.tileFin * 5, graphic.tileFin * 8, 30);
                            entities.add(spider0);
                            notification("Enemy spawned");
                            break;
                        case 2:
                            //SECTOR C
                            Enemy spider2 = new Enemy(graphic.tileFin * 44, graphic.tileFin * 30, 30);
                            entities.add(spider2);
                            notification("Enemy spawned");
                            break;
                        case 3:
                            //SPAWN
                            Enemy spider3 = new Enemy(graphic.tileFin * 5, graphic.tileFin * 15, 30);
                            entities.add(spider3);
                            notification("Enemy spawned");
                            break;
                        case 4:
                            //SECTOR A
                            Enemy spider4 = new Enemy(graphic.tileFin * 39, graphic.tileFin * 4, 30);
                            entities.add(spider4);
                            notification("Enemy spawned");
                            break;
                        case 5:
                            //SECTOR E
                            Enemy spider5 = new Enemy(graphic.tileFin * 31, graphic.tileFin * 44, 30);
                            entities.add(spider5);
                            notification("Enemies spawned");

                            //SECTOR B
                            Enemy spider6 = new Enemy(graphic.tileFin * 38, graphic.tileFin * 16, 30);
                            entities.add(spider6);
                            break;
                    }
                }
            } else {
                if (graphic.currentMap == 1){

                    if (point > 0){
                        switch (point){
                            case 1:
                                //SECTOR A
                                Enemy spider1 = new Enemy(graphic.tileFin * 30, graphic.tileFin * 12, 40);
                                entities.add(spider1);
                                notification("Enemy spawned");
                                break;
                            case 2:
                                //SPAWN
                                Enemy spider2 = new Enemy(graphic.tileFin * 8, graphic.tileFin * 20, 40);
                                entities.add(spider2);
                                notification("Enemy spawned");
                                break;
                            case 3:
                                //SECTOR C
                                Enemy spider3 = new Enemy(graphic.tileFin * 37, graphic.tileFin * 34, 40);
                                entities.add(spider3);
                                notification("Enemies spawned");

                                //SECTOR B
                                Enemy spider4 = new Enemy(graphic.tileFin * 15, graphic.tileFin * 19, 40);
                                entities.add(spider4);
                                break;
                            case 4:
                                //SECTOR E
                                Enemy spider5 = new Enemy(graphic.tileFin * 44, graphic.tileFin * 13, 40);
                                entities.add(spider5);
                                notification("Enemy spawned");
                                break;
                            case 5:
                                //SECTOR D
                                Enemy spider6 = new Enemy(graphic.tileFin * 11, graphic.tileFin * 41, 40);
                                entities.add(spider6);
                                notification("Enemies spawned");
                                break;
                            case 6:
                                //SECTOR A
                                Enemy spider7 = new Enemy(graphic.tileFin * 7, graphic.tileFin * 16, 40);
                                entities.add(spider7);
                                notification("Enemies spawned");

                                //SECTOR C
                                Enemy spider8 = new Enemy(graphic.tileFin * 22, graphic.tileFin * 30, 40);
                                entities.add(spider8);
                                break;
                            case 7:
                                //SECTOR D
                                Enemy spider9 = new Enemy(graphic.tileFin * 31, graphic.tileFin * 44, 40);
                                entities.add(spider9);
                                notification("Enemy spawned");
                                break;
                            case 8:
                                //SECTOR E
                                Enemy spider10 = new Enemy(graphic.tileFin * 36, graphic.tileFin * 6, 40);
                                entities.add(spider10);
                                notification("Enemy spawned");
                                break;

                        }
                    }
                } else {
                    if (graphic.currentMap == 2){
                        if (point > 0){
                            switch (point){
                                case 1:
                                    //SPAWN
                                    Enemy spider1 = new Enemy(graphic.tileFin * 16, graphic.tileFin * 20, 20);
                                    entities.add(spider1);
                                    notification("Enemies spawned");

                                    Enemy spider2 = new Enemy(graphic.tileFin * 9, graphic.tileFin * 10, 20);
                                    entities.add(spider2);
                                    break;
                                case 2:
                                    //SECTOR C
                                    Enemy spider3 = new Enemy(graphic.tileFin * 44, graphic.tileFin * 40, 20);
                                    entities.add(spider3);
                                    notification("Enemies spawned");

                                    //SECTOR B
                                    Enemy spider4 = new Enemy(graphic.tileFin * 9, graphic.tileFin * 40, 20);
                                    entities.add(spider4);
                                    break;
                                case 3:
                                    //SECTOR A
                                    Enemy spider5 = new Enemy(graphic.tileFin * 16, graphic.tileFin * 36, 20);
                                    entities.add(spider5);
                                    notification("Enemies spawned");

                                    //SECTOR D
                                    Enemy spider6 = new Enemy(graphic.tileFin * 31, graphic.tileFin * 26, 20);
                                    entities.add(spider6);
                                case 4:
                                    //SECTOR B
                                    Enemy spider7 = new Enemy(graphic.tileFin * 32, graphic.tileFin * 42, 20);
                                    entities.add(spider7);
                                    notification("Enemies spawned");

                                    //SECTOR E
                                    Enemy spider8 = new Enemy(graphic.tileFin * 19, graphic.tileFin * 10, 20);
                                    entities.add(spider8);
                                    break;
                                case 5:
                                    //SECTOR C
                                    Enemy spider9 = new Enemy(graphic.tileFin * 29, graphic.tileFin * 16, 20);
                                    entities.add(spider9);
                                    notification("Enemy spawned");
                                    break;
                                case 6:
                                    //SECTOR A
                                    Enemy spider10 = new Enemy(graphic.tileFin * 6, graphic.tileFin * 26, 20);
                                    entities.add(spider10);
                                    notification("Enemies spawned");

                                    //SECTOR C
                                    Enemy spider11 = new Enemy(graphic.tileFin * 25, graphic.tileFin * 34, 20);
                                    entities.add(spider11);

                                    //SECTOR D
                                    Enemy spider12 = new Enemy(graphic.tileFin * 43, graphic.tileFin * 11, 20);
                                    entities.add(spider12);
                                    break;
                                case 8:
                                    //SECTOR D
                                    Enemy spider13 = new Enemy(graphic.tileFin * 34, graphic.tileFin * 28, 20);
                                    entities.add(spider13);
                                    notification("Enemy spawned");
                                case 9:
                                    //SECTOR E
                                    Enemy spider14 = new Enemy(graphic.tileFin * 41, graphic.tileFin * 8, 20);
                                    entities.add(spider14);
                                    notification("Enemies spawned");

                                    //SECTOR B
                                    Enemy spider15 = new Enemy(graphic.tileFin * 39, graphic.tileFin * 17, 20);
                                    entities.add(spider15);
                                    break;
                                case 11:
                                    //SECTOR E
                                    Enemy spider16 = new Enemy(graphic.tileFin * 23, graphic.tileFin * 45, 20);
                                    entities.add(spider16);
                                    notification("Enemy spawned");
                                    break;

                            }
                        }
                    }
                }
            }
        }
    }
    public void update() throws IOException {

        if (gameState == lvl){
            counter++;
            if (counter > 200){
                cCheck = new CollisionCheck(graphic, tileCheck);
                projectileList.clear();
                entities.clear();
                player.setDefault();
                level++;
                graphic.currentMap++;
                point = 0;
                weaponCount = 0;
                saveCurrentLevel();
                AS.spawnWeapon();
                AS.setITile();
                System.out.println(graphic.currentMap);
                counter = 0;
                gameState = play;
            }
        }

        if (gameState == play){
            if (panel.upPressed || panel.downPressed || panel.leftPressed || panel.rightPressed){
                if (panel.upPressed){
                    player.direction = "up";
                }
                if (panel.downPressed){
                    player.direction = "down";
                }
                if (panel.leftPressed){
                    player.direction = "left";
                }
                if (panel.rightPressed){
                    player.direction = "right";
                }

                player.collisionOn = false;
                cCheck.checkTile(player);
                if (!player.collisionOn) {
                    switch (player.direction){
                        case "up":
                            player.getCoord().y -= player.speed;
                            break;
                        case "down":
                            player.getCoord().y += player.speed;
                            break;
                        case "left":
                            player.getCoord().x -= player.speed;
                            break;
                        case "right":
                            player.getCoord().x += player.speed;
                            break;
                    }
                }

                player.spriteCounter++;
                if (player.spriteCounter > 14){
                    if (player.spriteNum == 1){
                        player.spriteNum = 2;
                    }
                    else if (player.spriteNum == 2){
                        player.spriteNum = 3;
                    }
                    else if (player.spriteNum == 3){
                        player.spriteNum = 4;
                    }
                    else if (player.spriteNum == 4){
                        player.spriteNum = 1;
                    }
                    player.spriteCounter = 0;
                }

            }
            else {
                player.standCounter++;
                if (player.standCounter == 20){
                    player.spriteNum = 2;
                    player.standCounter = 0;
                }
            }


            for (int i = 0; i < weapon.length; i++) {

                if (weapon[i] != null && weapon[i].interactive) {
                    Rectangle playerBounds = new Rectangle(player.getCoord().x, player.getCoord().y, 32, 32);
                    Rectangle weaponBounds = new Rectangle(weapon[i].x, weapon[i].y, 32, 32);

                    if (playerBounds.intersects(weaponBounds)) {
                        if (weaponCount < 3) {
                            weapon[i] = null;
                            weaponCount++;
                            notification("Weapon picked up, ready to shoot!");

                            if (weaponCount == 3) {
                                notification("Limit reached");
                            }
                        } else {
                            notification("Nah fluff off. I said limit reached you greedy thing");
                        }
                        break;
                    }
                }
            }

            if (panel.fPressed && weaponCount == 0 && System.currentTimeMillis() - lastShootTime >= SHOOT_COOLDOWN){
                if (randomMessage == 0){
                    notification("Got nothing on ya buddy");
                    randomMessage++;
                } else {
                    if (randomMessage == 1){
                        notification("Lmao what ya trying?");
                        randomMessage++;
                    } else {
                        if (randomMessage == 2){
                            notification("What you gonna hit with that?! Air?!");
                            randomMessage = 0;
                        }
                    }
                }
                lastShootTime = System.currentTimeMillis();
            }
            if (panel.ePressed) {
                for (int i = 0; i < iTile.length; i++) {
                    if (iTile[i] != null && iTile[i].interactive) {
                        int playerX = player.getCoord().x;
                        int playerY = player.getCoord().y;
                        int tileX = iTile[i].x;
                        int tileY = iTile[i].y;

                        if (isNear(playerX, playerY, tileX, tileY)) {
                            iTile[i] = null;
                            point++;
                            initialize();
                            if (graphic.currentMap == 0) {
                                if (point == 6) {
                                    gameState = lvl;
                                }
                                break;
                            } else {
                                if (graphic.currentMap == 1) {
                                    if (point == 9) {
                                        gameState = lvl;
                                    }
                                    break;
                                } else {
                                    if (graphic.currentMap == 2) {
                                        if (point == 12) {
                                            gameState = end;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (panel.fPressed && !player.projectile.alive && weaponCount > 0 && System.currentTimeMillis() - lastShootTime >= SHOOT_COOLDOWN) {
                if (graphic.currentMap == 0){
                    Projectile newProjectile = new Projectile(player.getCoord().x, player.getCoord().y, 15);
                    newProjectile.set(player.getCoord().x, player.getCoord().y, player.direction, true);
                    projectileList.add(newProjectile);
                    System.out.println(newProjectile.damage);
                } else {
                    if (graphic.currentMap == 1){
                        Projectile newProjectile = new Projectile(player.getCoord().x, player.getCoord().y, 10);
                        newProjectile.set(player.getCoord().x, player.getCoord().y, player.direction, true);
                        projectileList.add(newProjectile);
                    } else {
                        Projectile newProjectile = new Projectile(player.getCoord().x, player.getCoord().y, 5);
                        newProjectile.set(player.getCoord().x, player.getCoord().y, player.direction, true);
                        projectileList.add(newProjectile);
                        System.out.println(newProjectile.damage);
                    }
                }


                if (switchSound()){
                    int randomValue = randomNum();
                    if (randomValue == 0 || randomValue == 2){
                        playSE(5);
                    } else {
                        playSE(7);
                    }
                } else {
                    playSE(10);
                }

                lastShootTime = System.currentTimeMillis();
                weaponCount--;
            }

            //PROJECTILES
            for (int p = 0; p < projectileList.size(); p++) {
                Projectile projectile = (Projectile) projectileList.get(p);
                if (projectile != null) {
                    if (projectile.alive) {
                        projectile.movement();
                    } else {
                        projectileList.remove(p);
                        p--;
                    }
                }
            }

            //ENTITIES AND PROJECTILES COLLISION
            Iterator<Entity> iterator = entities.iterator();
            while (iterator.hasNext()) {
                Entity entity = iterator.next();
                if (entity instanceof Enemy) {
                    for (int p = 0; p < projectileList.size(); p++) {
                        Projectile projectile = (Projectile) projectileList.get(p);
                        Rectangle entityBounds = new Rectangle(entity.getCoord().x, entity.getCoord().y, 32, 32);
                        Rectangle shotBounds = new Rectangle(projectile.getCoord().x, projectile.getCoord().y, 32, 32);

                        if (shotBounds.intersects(entityBounds)) {
                            projectile.alive = false;
                            System.out.println(((Enemy) entity).health);
                            System.out.println(projectile.damage);
                            ((Enemy) entity).health -= projectile.damage;
                            int randomValue = randomNum();
                            if (randomValue == 0 || randomValue == 2 && (((Enemy) entity).health -= projectile.damage) >= 0){
                                playSE(8);
                            }
                            notification("Hit!");
                            if (((Enemy) entity).health <= 0) {
                                if (randomValue == 0 || randomValue == 2){
                                    playSE(1);
                                } else {
                                    playSE(0);
                                }
                                iterator.remove();
                                notification("Got em!");
                            }
                        }
                    }
                }
            }

            //BOUNDS
            for (Entity entity : getEntities()) {
                if (entity instanceof Enemy enemy) {
                    Rectangle entityBounds = new Rectangle(enemy.getCoord().x + 16, enemy.getCoord().y - 32, 64, 64);
                    Rectangle playerBounds = new Rectangle(player.getCoord().x + 16, player.getCoord().y - 32, 64, 64);
                    if (playerBounds.intersects(entityBounds)){
                        gameState = menu;

                    }

                }
            }
            followPlayer();

            //ANIMATION
            for (Entity entity : entities){
                if (entity instanceof Enemy enemy) {
                    enemy.spriteCounter++;
                    if (enemy.spriteCounter > 14){
                        if (enemy.spriteNum == 1){
                            enemy.spriteNum = 2;
                        }
                        else if (enemy.spriteNum == 2){
                            enemy.spriteNum = 3;
                        }
                        else if (enemy.spriteNum == 3){
                            enemy.spriteNum = 4;
                        }
                        else if (enemy.spriteNum == 4){
                            enemy.spriteNum = 1;
                        }
                        enemy.spriteCounter = 0;
                    }
                }
            }
            graphic.render(this);
        }
    }

    private boolean isNear(int playerX, int playerY, int tileX, int tileY) {
        int threshold = graphic.tileFin;
        return Math.abs(playerX - tileX) <= threshold && Math.abs((playerY + 5) - tileY) <= threshold;
    }

    public ArrayList<Entity> getEntities() {
        return entities;
    }

    public ArrayList<Entity> getProjectiles() {
        return projectileList;
    }
    public void notification(String text){
        message = text;
        messageOn = true;
    }
    public void playSE(int i){
        sound.setFile(i);
        sound.play();
    }

    public int randomNum(){
        Random random = new Random();
        randomNumber = random.nextInt(4);
        return randomNumber;
    }
    public boolean switchSound(){
        Random random = new Random();
        return random.nextInt(100) == 13;
    }
    public void saveCurrentLevel() {
        try (PrintWriter writer = new PrintWriter(currentLevel)) {
            writer.println(level);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public int loadCurrentLevel() {
        File file = new File(currentLevel);
        if (!file.exists() || file.length() == 0) {
            return 1;
        }

        try (Scanner scanner = new Scanner(file)) {
            if (scanner.hasNextInt()) {
                level = scanner.nextInt();
                return level;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 1;
    }
    public void followPlayer() {

        for (Entity entity : getEntities()) {
            if (entity instanceof Enemy enemy) {
                enemy.collisionOn = false;
                cCheck.checkTile(enemy);

                Rectangle entityBounds = new Rectangle(enemy.getCoord().x - graphic.tileFin, enemy.getCoord().y - graphic.tileFin, graphic.tileFin * 3, graphic.tileFin * 3);
                Rectangle playerBounds = new Rectangle(player.getCoord().x - graphic.tileFin * 2, player.getCoord().y - graphic.tileFin - 2, graphic.tileFin * 5, graphic.tileFin * 5);

                if (playerBounds.intersects(entityBounds)){

                    int differenceX = Math.abs(player.getCoord().x - enemy.getCoord().x);
                    int differenceY = Math.abs(player.getCoord().y - enemy.getCoord().y);

                    if (differenceX < differenceY) {
                        if (player.getCoord().y > enemy.getCoord().y) {
                            enemy.direction = "down";
                        } else {
                            enemy.direction = "up";
                        }
                    } else {
                        if (player.getCoord().x > enemy.getCoord().x) {
                            enemy.direction = "right";
                        } else {
                            enemy.direction = "left";
                        }
                    }

                    if (!enemy.collisionOn){
                        switch (enemy.direction){
                            case "up":
                                enemy.getCoord().y -= enemy.speed;
                                break;
                            case "down":
                                enemy.getCoord().y += enemy.speed;
                                break;
                            case "left":
                                enemy.getCoord().x -= enemy.speed;
                                break;
                            case "right":
                                enemy.getCoord().x += enemy.speed;
                                break;
                        }
                    }

                    if (enemy.collisionOn) {

                        switch (enemy.direction) {
                            case "up":
                                enemy.getCoord().x -= enemy.speed;
                                cCheck.checkTile(enemy);
                                if (!enemy.collisionOn){
                                    counter++;
                                    if (counter < 200){
                                        enemy.getCoord().x -= enemy.speed;
                                        counter = 0;
                                    }
                                }
                                if (enemy.collisionOn){
                                    enemy.getCoord().x += enemy.speed;
                                    cCheck.checkTile(enemy);
                                    if (!enemy.collisionOn){
                                        counter++;
                                        if (counter < 200){
                                            enemy.getCoord().x += enemy.speed;
                                            counter = 0;
                                        }
                                    }
                                } else {
                                    enemy.getCoord().y += enemy.speed;
                                    cCheck.checkTile(enemy);
                                    if (!enemy.collisionOn){
                                        counter++;
                                        if (counter < 200){
                                            enemy.getCoord().y += enemy.speed;
                                            counter = 0;
                                        }
                                    }
                                }
                                break;
                            case "down":
                                enemy.getCoord().x += enemy.speed;
                                cCheck.checkTile(enemy);
                                if (!enemy.collisionOn){
                                    counter++;
                                    if (counter < 200){
                                        enemy.getCoord().x += enemy.speed;
                                        counter = 0;
                                    }
                                }
                                if (enemy.collisionOn){
                                    enemy.getCoord().y -= enemy.speed;
                                    cCheck.checkTile(enemy);
                                    if (!enemy.collisionOn){
                                        counter++;
                                        if (counter < 200){
                                            enemy.getCoord().y -= enemy.speed;
                                            counter = 0;
                                        }
                                    }
                                } else {
                                    enemy.getCoord().x -= enemy.speed;
                                    cCheck.checkTile(enemy);
                                    if (!enemy.collisionOn){
                                        counter++;
                                        if (counter < 200){
                                            enemy.getCoord().x -= enemy.speed;
                                            counter = 0;
                                        }
                                    }
                                }
                                break;
                            case "left":
                                enemy.getCoord().y += enemy.speed;
                                cCheck.checkTile(enemy);
                                if (!enemy.collisionOn){
                                    counter++;
                                    if (counter < 200){
                                        enemy.getCoord().y += enemy.speed;
                                        counter = 0;
                                    }
                                }
                                if (enemy.collisionOn){
                                    enemy.getCoord().x += enemy.speed;
                                    cCheck.checkTile(enemy);
                                    if (!enemy.collisionOn){
                                        counter++;
                                        if (counter < 200){
                                            enemy.getCoord().x += enemy.speed;
                                            counter = 0;
                                        }
                                    }
                                } else {
                                    enemy.getCoord().y -= enemy.speed;
                                    cCheck.checkTile(enemy);
                                    if (!enemy.collisionOn){
                                        counter++;
                                        if (counter < 200){
                                            enemy.getCoord().y -= enemy.speed;
                                            counter = 0;
                                        }
                                    }
                                }
                                break;
                            case "right":
                                enemy.getCoord().y -= enemy.speed;
                                cCheck.checkTile(enemy);
                                if (!enemy.collisionOn){
                                    counter++;
                                    if (counter < 200){
                                        enemy.getCoord().y -= enemy.speed;
                                        counter = 0;
                                    }
                                }
                                if (enemy.collisionOn){
                                    enemy.getCoord().x -= enemy.speed;
                                    cCheck.checkTile(enemy);
                                    if (!enemy.collisionOn){
                                        counter++;
                                        if (counter < 200){
                                            enemy.getCoord().x -= enemy.speed;
                                            counter = 0;
                                        }
                                    }
                                } else {
                                    enemy.getCoord().y += enemy.speed;
                                    cCheck.checkTile(enemy);
                                    if (!enemy.collisionOn){
                                        counter++;
                                        if (counter < 200){
                                            enemy.getCoord().y += enemy.speed;
                                            counter = 0;
                                        }
                                    }
                                }
                                break;
                        }
                    }
                }
            }
        }
    }
}