package org.example.projectile;

import org.example.entity.Entity;

import javax.imageio.ImageIO;
import java.io.IOException;


public class Projectile extends Entity{
    public int speed;
    public int damage;
    public int life;
    public boolean alive = false;

    public Projectile(int x, int y, int damage) {
        super(x, y);
        this.speed = 8;
        this.damage = damage;
        getPImage();
    }

    public void set(int x, int y, String direction, boolean alive){
        this.getCoord().x = x;
        this.getCoord().y = y;
        this.direction = direction;
        this.alive = alive;
        this.life = 80;

    }
    public void getPImage(){

        try{
            up1 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_up1.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_up2.png"));
            up3 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_up3.png"));
            up4 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_up4.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_down1.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_down2.png"));
            down3 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_down3.png"));
            down4 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_down4.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_left1.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_left2.png"));
            left3 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_left3.png"));
            left4 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_left4.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_right1.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_right2.png"));
            right3 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_right3.png"));
            right4 = ImageIO.read(getClass().getResourceAsStream("/projectile/P_right4.png"));

        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public void movement(){

        switch (direction){
            case "up":
                getCoord().y -= speed;
                break;
            case "down":
                getCoord().y += speed;
                break;
            case "left":
                getCoord().x -= speed;
                break;
            case "right":
                getCoord().x += speed;
                break;
        }

        life--;
        if (life <= 0){
            alive = false;
        }

        spriteCounter++;
        if (spriteCounter > 14){
            if (spriteNum == 1){
                spriteNum = 2;
            }
            else if (spriteNum == 2){
                spriteNum = 3;
            }
            else if (spriteNum == 3){
                spriteNum = 4;
            }
            else if (spriteNum == 4){
                spriteNum = 1;
            }
            spriteCounter = 0;
        }
    }
}