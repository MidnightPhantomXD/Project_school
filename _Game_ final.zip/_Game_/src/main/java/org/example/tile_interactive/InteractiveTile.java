package org.example.tile_interactive;

import org.example.GameGraphics;
import org.example.Logic;
import org.example.entity.Coordinates;
import org.example.tile.Tile;

import java.awt.image.BufferedImage;


public class InteractiveTile extends Coordinates {
    public boolean interactive = false;
    public Tile[] tileInt;
    public InteractiveTile(int x, int y) {
        super(x, y);
        this.tileInt = new Tile[1];
        this.tileInt[0] = new Tile();

    }
}
