package org.example;

import org.example.entity.Enemy;
import org.example.entity.Entity;
import org.example.entity.Player;
import org.example.projectile.Projectile;
import org.example.tile.Tile;
import org.example.tile.TileCheck;
import org.example.tile_interactive.InteractiveTile;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class GameGraphics extends JFrame{
    public final int defTileSize = 48; //default tile
    public final int tileFin = defTileSize * 2;
    public final int maxScreenCol = 12; //how many tiles is a screen
    public final int maxScreenRow = 16; //how many tiles is a screen
    public final int screenWidth = (tileFin * maxScreenRow) / 2 + 312; //make it 1080
    public final int screenHeight = (tileFin * maxScreenCol) / 2 + 144; //make it 720
    public final int maxWorldCol = 50;
    public final int maxWorldRow = 50;
    public final int maxMap = 3;
    public int currentMap = 0;
    public int commandNum = 0;
    public int nextPage = 0;
    BufferedImage paper;
    BufferedImage darknessFilter;
    Tutorial tutorial;
    Draw draw;
    Logic logic;
    TileCheck tileCheck;
    Tile[] tile;
    Sound sound;

    public GameGraphics(Logic logic) throws HeadlessException {

        this.logic = logic;
        this.tileCheck = new TileCheck(this);
        this.tile = tileCheck.tile;
        this.tutorial = new Tutorial();
        this.sound = new Sound();
        Projectile paper_p = new Projectile(10, 10, 0);
        paper = paper_p.up1;

        this.draw = new Draw();
        add(draw);

        setSize(screenWidth, screenHeight);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setTitle("Night shift");
        setIconImage(tutorial.image);

    }
    public void render(Logic logic) {
        this.logic = logic;
        repaint();
    }

    public class Draw extends JPanel {
        @Override
        protected void paintComponent(java.awt.Graphics g) {
            super.paintComponent(g);
            setBackground(Color.black);

            Graphics2D g2 = (Graphics2D)g;

            if (logic.gameState == logic.menu){
                //BACKGROUND
                g2.drawImage(tutorial.bg, 0,0, null);

                //TITLE
                g2.setFont(new Font("Screen", Font.PLAIN, 80));
                g2.setColor(Color.white);
                g2.drawString("NIGHT SHIFT",  305, 100);

                //MENU
                g2.setFont(new Font("Screen", Font.PLAIN, 40));
                g2.setColor(Color.white);
                g2.drawString("NEW GAME", 430, 500);
                if (commandNum == 0){
                    g2.drawString(">", 400, 500);
                }

                g2.setFont(new Font("Screen", Font.PLAIN, 40));
                g2.setColor(Color.white);
                g2.drawString("LOAD GAME", 423, 560);
                if (commandNum == 1){
                    g2.drawString(">", 393, 560);
                }

                g2.setFont(new Font("Screen", Font.PLAIN, 40));
                g2.setColor(Color.white);
                g2.drawString("TUTORIAL", 440, 620);
                if (commandNum == 2){
                    g2.drawString(">", 410, 620);
                }

            } else {
                if (logic.gameState == logic.tutorial){

                    if (nextPage == 1){

                        g2.setFont(new Font("Font", Font.PLAIN, 60));
                        g2.setColor(Color.white);
                        g2.drawString("MOVEMENT", 90, 100);
                        g2.drawString("OTHER", 710, 100);

                        g2.drawImage(tutorial.W, 200, 150, tileFin, tileFin, null);
                        g2.drawImage(tutorial.S, 200, 150 + tileFin, tileFin, tileFin, null);
                        g2.drawImage(tutorial.A, 200 - tileFin, 150 + tileFin, tileFin, tileFin, null);
                        g2.drawImage(tutorial.D, 200 + tileFin, 150 + tileFin, tileFin, tileFin, null);
                        g2.drawImage(tutorial.E, 620, 190, tileFin, tileFin, null);
                        g2.drawImage(tutorial.F, 620, 270 + tileFin, tileFin, tileFin, null);

                        g2.setFont(new Font("Text", Font.PLAIN, 25));
                        g2.setColor(Color.white);
                        g2.drawString("Player's only keys for", 144, 450);
                        g2.drawString("movement are W, S, A, D.", 116, 500);
                        g2.drawString("Not arrows", 195, 550);
                        g2.drawString("---", 730, 252);
                        g2.drawString("Used to get points", 770, 256);
                        g2.drawString("---", 730, 430);
                        g2.drawString("Used to shoot projectiles", 770, 434);

                        g2.setFont(new Font("Switch", Font.PLAIN, 30));
                        g2.setColor(Color.white);
                        g2.drawString("Back", 50, 635);
                        g2.drawString("Next", 945, 635);
                    }
                    if (nextPage == 2){

                        g2.setFont(new Font("Font", Font.PLAIN, 60));
                        g2.setColor(Color.white);
                        g2.drawString("GOAL", 440, 100);

                        g2.setFont(new Font("Text2", Font.PLAIN, 15));
                        g2.setColor(Color.white);
                        g2.drawImage(tutorial.shelf, 80, 450, tileFin, tileFin, null);
                        g2.drawImage(tutorial.box, 80 + tileFin, 450, tileFin, tileFin, null);
                        g2.drawString("To get a point find these tiles", 80, 420);

                        g2.drawImage(tutorial.floor, 460, 450, tileFin, tileFin, null);
                        g2.drawImage(tutorial.projectile, 460, 450, tileFin, tileFin, null);
                        g2.drawString("Pick up projectiles", 445, 420);


                        g2.drawImage(tutorial.lFloor, 700, 450, tileFin, tileFin, null);
                        g2.drawImage(tutorial.lFloor, 700 + tileFin, 450, tileFin, tileFin, null);
                        g2.drawImage(tutorial.lFloor, 700 + tileFin * 2, 450 , tileFin, tileFin, null);
                        g2.drawImage(tutorial.enemy, 700 + tileFin * 2, 450, tileFin, tileFin, null);
                        g2.drawImage(logic.player.right2, 700, 450, tileFin, tileFin, null);
                        g2.drawImage(tutorial.projectile, 700 + tileFin, 450, tileFin, tileFin, null);
                        g2.drawString("Kill spiders", 800, 420);

                        g2.setFont(new Font("Text2", Font.PLAIN, 15));
                        g2.setColor(Color.white);

                        g2.drawString("The goal of this game is to get a certain amount of points to finish a level and in the meantime not get killed by spiders.", 125, 150);
                        g2.drawString("There are five sectors plus a spawn area. Points may or may not be in every sector or the spawn area.", 170, 180);
                        g2.drawString("To get a point come up to a tile that has a question mark on it and press E. This way a point is added to you.", 150, 210);
                        g2.drawString("Every time you get a point, a new spider or more spawn somewhere on the map, depends on the level.", 173, 240);
                        g2.drawString("To reduce the amount of spiders on the map there are also projectiles - a peace of paper, laying somewhere around the map.", 101, 270);
                        g2.drawString("Be careful though because there is a carry limit and the higher level the less projectiles to get!", 193, 300);
                        g2.drawString("Each level has certain amount of projectiles, points to finish the level and number of enemies that can spawn.", 150, 330);

                        g2.setFont(new Font("Switch", Font.PLAIN, 30));
                        g2.setColor(Color.white);
                        g2.drawString("Back", 50, 635);
                        g2.drawString("Next", 945, 635);
                    }
                    if (nextPage == 3){

                        g2.setFont(new Font("Text2", Font.PLAIN, 20));
                        g2.setColor(Color.white);

                        g2.drawString("Level 1:", 100, 80);
                        g2.drawString("Points distribution: All areas one", 100, 120);
                        g2.drawString("Points to get: 6", 100, 160);
                        g2.drawString("Spiders able to spawn: 6", 100, 200);
                        g2.drawString("Spider health: 30", 100, 240);
                        g2.drawString("Projectiles on map: 12", 100, 280);
                        g2.drawString("Projectile damage: 15", 100, 320);

                        g2.drawString("Level 2:", 640, 80);
                        g2.drawString("Points distribution: Not every area has a point", 640, 120);
                        g2.drawString("Points to get: 9", 640, 160);
                        g2.drawString("Spiders able to spawn: 10", 640, 200);
                        g2.drawString("Spider health: 40", 640, 240);
                        g2.drawString("Projectiles on map: 24", 640, 280);
                        g2.drawString("Projectile damage: 10", 640, 320);

                        g2.drawString("Level 3:", 330, 380);
                        g2.drawString("Points distribution: All areas have a point or more", 330, 420);
                        g2.drawString("Points to get: 12", 330, 460);
                        g2.drawString("Spiders able to spawn: 16", 330, 500);
                        g2.drawString("Spider health: 20", 330, 540);
                        g2.drawString("Projectiles on map: 36", 330, 580);
                        g2.drawString("Projectile damage: 5", 330, 620);

                        g2.setFont(new Font("Switch", Font.PLAIN, 30));
                        g2.setColor(Color.white);
                        g2.drawString("Back", 50, 635);
                        g2.drawString("Next", 945, 635);
                    }
                    if (nextPage == 4){

                        g2.setFont(new Font("Font2", Font.PLAIN, 40));
                        g2.setColor(Color.white);
                        g2.drawString("UNDERSTOOD!", 380, 390);

                        g2.setFont(new Font("Text", Font.PLAIN, 25));
                        g2.setColor(Color.white);
                        g2.drawString("Good luck!", 460, 100);
                        g2.drawString("(Btw press enter)", 430, 140);

                        g2.drawImage(tutorial.smile, 380 + tileFin, 400 + tileFin, tileFin, tileFin, null);

                        g2.setFont(new Font("Switch", Font.PLAIN, 30));
                        g2.setColor(Color.white);
                        g2.drawString("Back", 50, 635);

                    }

                    if (nextPage == 0){
                        logic.gameState = logic.menu;
                    }


                } else {
                    if (logic.gameState == logic.lvl) {

                        g2.setFont(new Font("Level", Font.PLAIN, 80));
                        g2.setColor(Color.white);
                        g2.drawString("Level " + logic.level, 400, 300);
                        g2.drawString("Finished", 375, 460);
                    } else {

                        if (logic.gameState == logic.end){

                            g2.setFont(new Font("Final", Font.PLAIN, 80));
                            g2.setColor(Color.white);
                            g2.drawString("CONGRATULATIONS", 145, 300);
                            g2.drawString("YOU WON!", 325, 420);
                            g2.setFont(new Font("Menu", Font.PLAIN, 30));
                            g2.drawString("Menu", 500, 600);
                            g2.drawString("Quit", 510, 650);
                            if (commandNum == 1){
                                g2.drawString(">", 470, 600);
                            } else {
                                if (commandNum == 2){
                                    g2.drawString(">", 480, 650);
                                }
                            }

                        } else {

                            Player player = logic.getPlayer();


                            //WORLD MAP
                            int worldRow = 0;
                            int worldCol = 0;

                            while (worldCol < maxWorldCol && worldRow < maxWorldRow) {

                                int tileNum = tileCheck.mapTileNum[currentMap][worldRow][worldCol];

                                int worldX = worldRow * tileFin;
                                int worldY = worldCol * tileFin;
                                int screenX = worldX - player.getCoord().x + player.screenX;
                                int screenY = worldY - player.getCoord().y + player.screenY;

                                if (worldX + tileFin > player.getCoord().x - player.screenX &&
                                        worldX - tileFin < player.getCoord().x + player.screenX &&
                                        worldY + tileFin > player.getCoord().y - player.screenY &&
                                        worldY - tileFin < player.getCoord().y + player.screenY) {

                                    g2.drawImage(tile[tileNum].image, screenX, screenY, tileFin, tileFin, null);
                                }
                                worldRow++;

                                if (worldRow == maxWorldRow) {
                                    worldRow = 0;
                                    worldCol++;

                                }
                            }

                            //INTERACTIVE TILES
                            for (InteractiveTile iTile : logic.iTile) {
                                if (iTile != null) {
                                    int worldX = iTile.x;
                                    int worldY = iTile.y;
                                    int screenX = worldX - player.getCoord().x + player.screenX;
                                    int screenY = worldY - player.getCoord().y + player.screenY;

                                    if (worldX + tileFin > player.getCoord().x - player.screenX &&
                                            worldX - tileFin < player.getCoord().x + player.screenX &&
                                            worldY + tileFin > player.getCoord().y - player.screenY &&
                                            worldY - tileFin < player.getCoord().y + player.screenY) {
                                        g2.drawImage(iTile.tileInt[0].image, screenX, screenY, tileFin, tileFin, null);
                                    }
                                }
                            }

                            //WEAPON
                            for (InteractiveTile weapon : logic.weapon) {
                                if (weapon != null) {
                                    int worldX = weapon.x;
                                    int worldY = weapon.y;
                                    int screenX = worldX - player.getCoord().x + player.screenX;
                                    int screenY = worldY - player.getCoord().y + player.screenY;

                                    if (worldX + tileFin > player.getCoord().x - player.screenX &&
                                            worldX - tileFin < player.getCoord().x + player.screenX &&
                                            worldY + tileFin > player.getCoord().y - player.screenY &&
                                            worldY - tileFin < player.getCoord().y + player.screenY) {
                                        g2.drawImage(weapon.tileInt[0].image, screenX, screenY, tileFin, tileFin, null);
                                    }
                                }
                            }

                            //PLAYER MOVEMENTS
                            BufferedImage image = null;

                            switch (player.direction) {
                                case "up":
                                    if (player.spriteNum == 1) {
                                        image = player.up2;
                                    } else if (player.spriteNum == 2) {
                                        image = player.up1;
                                    } else if (player.spriteNum == 3) {
                                        image = player.up3;
                                    } else if (player.spriteNum == 4) {
                                        image = player.up1;
                                    }
                                    break;
                                case "down":
                                    if (player.spriteNum == 1) {
                                        image = player.down2;
                                    } else if (player.spriteNum == 2) {
                                        image = player.down1;
                                    } else if (player.spriteNum == 3) {
                                        image = player.down3;
                                    } else if (player.spriteNum == 4) {
                                        image = player.down1;
                                    }
                                    break;
                                case "left":
                                    if (player.spriteNum == 1) {
                                        image = player.left2;
                                    } else if (player.spriteNum == 2) {
                                        image = player.left1;
                                    } else if (player.spriteNum == 3) {
                                        image = player.left3;
                                    } else if (player.spriteNum == 4) {
                                        image = player.left1;
                                    }
                                    break;
                                case "right":
                                    if (player.spriteNum == 1) {
                                        image = player.right2;
                                    } else if (player.spriteNum == 2) {
                                        image = player.right1;
                                    } else if (player.spriteNum == 3) {
                                        image = player.right3;
                                    } else if (player.spriteNum == 4) {
                                        image = player.right1;
                                    }
                                    break;
                            }
                            g2.drawImage(image, player.screenX, player.screenY, tileFin, tileFin, null);

                            //SPIDERS
                            for (Entity entity : logic.getEntities()) {
                                if (entity instanceof Enemy enemy) {

                                    int screenX = enemy.getCoord().x - player.getCoord().x + player.screenX;
                                    int screenY = enemy.getCoord().y - player.getCoord().y + player.screenY;

                                    Rectangle entityBounds = new Rectangle(enemy.getCoord().x - tileFin, enemy.getCoord().y - tileFin, tileFin * 3, tileFin * 3);
                                    Rectangle playerBounds = new Rectangle(player.getCoord().x - tileFin * 2, player.getCoord().y - tileFin - 2, tileFin * 5, tileFin * 5);


                                    if (playerBounds.intersects(entityBounds)) {
                                        if (!enemy.played) {
                                            if (!logic.switchSound()) {
                                                int randomValue = logic.randomNum();
                                                if (randomValue == 0 || randomValue == 2) {
                                                    logic.playSE(3);
                                                    enemy.played = true;
                                                } else {
                                                    logic.playSE(4);
                                                    enemy.played = true;
                                                }
                                            } else {
                                                int randomValue = logic.randomNum();
                                                if (randomValue == 0) {
                                                    logic.playSE(2);
                                                    enemy.played = true;
                                                } else if (randomValue == 1) {
                                                    logic.playSE(6);
                                                    enemy.played = true;
                                                } else if (randomValue == 2) {
                                                    logic.playSE(9);
                                                    enemy.played = true;
                                                } else if (randomValue == 3) {
                                                    logic.playSE(11);
                                                    enemy.played = true;
                                                }
                                            }
                                        }
                                    } else {
                                        enemy.played = false;
                                    }


                                    BufferedImage enemyImage = null;
                                    switch (entity.direction) {
                                        case "up":
                                            if (enemy.spriteNum == 1) {
                                                enemyImage = enemy.up1;
                                            }
                                            if (enemy.spriteNum == 2) {
                                                enemyImage = enemy.up2;
                                            }
                                            if (enemy.spriteNum == 3) {
                                                enemyImage = enemy.up3;
                                            }
                                            if (enemy.spriteNum == 4) {
                                                enemyImage = enemy.up2;
                                            }
                                            break;
                                        case "down":
                                            if (enemy.spriteNum == 1) {
                                                enemyImage = enemy.down1;
                                            }
                                            if (enemy.spriteNum == 2) {
                                                enemyImage = enemy.down2;
                                            }
                                            if (enemy.spriteNum == 3) {
                                                enemyImage = enemy.down3;
                                            }
                                            if (enemy.spriteNum == 4) {
                                                enemyImage = enemy.down2;
                                            }
                                            break;
                                        case "left":
                                            if (enemy.spriteNum == 1) {
                                                enemyImage = enemy.left1;
                                            }
                                            if (enemy.spriteNum == 2) {
                                                enemyImage = enemy.left2;
                                            }
                                            if (enemy.spriteNum == 3) {
                                                enemyImage = enemy.left3;
                                            }
                                            if (enemy.spriteNum == 4) {
                                                enemyImage = enemy.left2;
                                            }
                                            break;
                                        case "right":
                                            if (enemy.spriteNum == 1) {
                                                enemyImage = enemy.right1;
                                            }
                                            if (enemy.spriteNum == 2) {
                                                enemyImage = enemy.right2;
                                            }
                                            if (enemy.spriteNum == 3) {
                                                enemyImage = enemy.right3;
                                            }
                                            if (enemy.spriteNum == 4) {
                                                enemyImage = enemy.right2;
                                            }
                                            break;
                                    }
                                    g2.drawImage(enemyImage, screenX, screenY, tileFin, tileFin, null);
                                }
                            }

                            //PROJECTILES
                            for (Entity projectile : logic.getProjectiles()) {

                                int screenX = projectile.getCoord().x - player.getCoord().x + player.screenX;
                                int screenY = projectile.getCoord().y - player.getCoord().y + player.screenY;

                                BufferedImage projectileImage = null;
                                switch (projectile.direction) {
                                    case "up":
                                        if (projectile.spriteNum == 1) {
                                            projectileImage = projectile.up1;
                                        }
                                        if (projectile.spriteNum == 2) {
                                            projectileImage = projectile.up2;
                                        }
                                        if (projectile.spriteNum == 3) {
                                            projectileImage = projectile.up3;
                                        }
                                        if (projectile.spriteNum == 4) {
                                            projectileImage = projectile.up4;
                                        }
                                        break;
                                    case "down":
                                        if (projectile.spriteNum == 1) {
                                            projectileImage = projectile.down1;
                                        }
                                        if (projectile.spriteNum == 2) {
                                            projectileImage = projectile.down2;
                                        }
                                        if (projectile.spriteNum == 3) {
                                            projectileImage = projectile.down3;
                                        }
                                        if (projectile.spriteNum == 4) {
                                            projectileImage = projectile.down4;
                                        }
                                        break;
                                    case "left":
                                        if (projectile.spriteNum == 1) {
                                            projectileImage = projectile.left1;
                                        }
                                        if (projectile.spriteNum == 2) {
                                            projectileImage = projectile.left2;
                                        }
                                        if (projectile.spriteNum == 3) {
                                            projectileImage = projectile.left3;
                                        }
                                        if (projectile.spriteNum == 4) {
                                            projectileImage = projectile.left4;
                                        }
                                        break;
                                    case "right":
                                        if (projectile.spriteNum == 1) {
                                            projectileImage = projectile.right1;
                                        }
                                        if (projectile.spriteNum == 2) {
                                            projectileImage = projectile.right2;
                                        }
                                        if (projectile.spriteNum == 3) {
                                            projectileImage = projectile.right3;
                                        }
                                        if (projectile.spriteNum == 4) {
                                            projectileImage = projectile.right4;
                                        }
                                        break;
                                }
                                g2.drawImage(projectileImage, screenX, screenY, tileFin, tileFin, null);
                            }

                            darknessFilter = new BufferedImage(screenWidth, screenHeight, BufferedImage.TYPE_INT_ARGB);
                            Area screenArea = new Area(new Rectangle2D.Double(0, 0, screenWidth, screenHeight));

                            int centerX = player.screenX + (tileFin)/2;
                            int centerY = player.screenY + (tileFin)/2;
                            int circleSize = 700;
                            double x = centerX - ((double) circleSize /2);
                            double y = centerY - ((double) circleSize /2);

                            Shape circleShape = new Ellipse2D.Double(x, y, circleSize, circleSize);
                            Area lightArea = new Area(circleShape);
                            screenArea.subtract(lightArea);

                            Color[] color = new Color[6];
                            float[] fraction = new float[6];

                            color[0] = new Color(0, 0, 0, 0f);
                            color[1] = new Color(0, 0, 0, 0.40f);
                            color[2] = new Color(0, 0, 0, 0.54f);
                            color[3] = new Color(0, 0, 0, 0.68f);
                            color[4] = new Color(0, 0, 0, 0.82f);
                            color[5] = new Color(0, 0, 0, 0.95f);

                            fraction[0] = 0f;
                            fraction[1] = 0.4f;
                            fraction[2] = 0.5f;
                            fraction[3] = 0.6f;
                            fraction[4] = 0.8f;
                            fraction[5] = 1f;

                            RadialGradientPaint gPaint = new RadialGradientPaint(centerX, centerY, (float) circleSize /2, fraction, color);
                            g2.setPaint(gPaint);
                            g2.fill(lightArea);

                            g2.fill(screenArea);
                            g2.drawImage(darknessFilter, 0, 0, null);

                            //POINTS AND WEAPONS COUNTER
                            g2.setFont(new Font("Points", Font.PLAIN, 40));
                            g2.setColor(Color.white);
                            g2.drawString("Points " + logic.point + " X", 50, 50);
                            g2.setFont(new Font("Weapon", Font.PLAIN, 40));
                            g2.setColor(Color.white);
                            g2.drawImage(paper, 53, 38, tileFin, tileFin, null);
                            g2.drawString(logic.weaponCount + "     X", 50, 100);

                            //MESSAGES
                            if (logic.messageOn) {
                                g2.setFont(new Font("Message", Font.PLAIN, 30));
                                g2.setColor(Color.white);
                                g2.drawString(logic.message, 50, tileFin * 7);

                                logic.counter++;
                                if (logic.counter > 120) {
                                    logic.counter = 0;
                                    logic.messageOn = false;
                                }
                            }

                            g2.dispose();
                        }
                    }
                }
            }
        }
    }
}
