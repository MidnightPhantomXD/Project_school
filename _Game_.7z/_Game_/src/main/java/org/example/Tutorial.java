package org.example;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Tutorial {
    public Image image;
    public BufferedImage W, S, A, D, E, F, enemy, projectile, shelf, box, floor, lFloor, smile, bg;

    public Tutorial() {
        getPImage();
    }

    public void getPImage(){

        try{
            image = ImageIO.read(getClass().getResourceAsStream("/tutorial/Icon.png"));
            W = ImageIO.read(getClass().getResourceAsStream("/tutorial/W.png"));
            S = ImageIO.read(getClass().getResourceAsStream("/tutorial/S.png"));
            A = ImageIO.read(getClass().getResourceAsStream("/tutorial/A.png"));
            D = ImageIO.read(getClass().getResourceAsStream("/tutorial/D.png"));
            E = ImageIO.read(getClass().getResourceAsStream("/tutorial/E.png"));
            F = ImageIO.read(getClass().getResourceAsStream("/tutorial/F.png"));
            enemy = ImageIO.read(getClass().getResourceAsStream("/tutorial/Front1_S.png"));
            projectile = ImageIO.read(getClass().getResourceAsStream("/tutorial/Paper.png"));
            shelf = ImageIO.read(getClass().getResourceAsStream("/tutorial/Shelf_I.png"));
            box = ImageIO.read(getClass().getResourceAsStream("/tutorial/Boxes_I.png"));
            floor = ImageIO.read(getClass().getResourceAsStream("/tutorial/Floor.png"));
            lFloor = ImageIO.read(getClass().getResourceAsStream("/tutorial/Light_floor.png"));
            smile = ImageIO.read(getClass().getResourceAsStream("/tutorial/Tutorial.png"));
            bg = ImageIO.read(getClass().getResourceAsStream("/tutorial/Background game.png"));


        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
