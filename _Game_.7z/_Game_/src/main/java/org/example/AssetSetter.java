package org.example;

import org.example.tile_interactive.IT_Weapon;
import org.example.tile_interactive.IT_Shelf;
import org.example.tile_interactive.IT_Box;

import javax.imageio.ImageIO;
import java.io.IOException;

public class AssetSetter {
    Logic logic;
    GameGraphics graphic;

    public AssetSetter(Logic logic, GameGraphics graphic) {
        this.logic = logic;
        this.graphic = graphic;
    }

    public void setITile() throws IOException{

        if (graphic.currentMap == 0){
            int i = 0;

            logic.iTile[i] = new IT_Box(graphic, 13, 10);
            logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

            logic.iTile[i] = new IT_Shelf(graphic, 5, 27);
            logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

            logic.iTile[i] = new IT_Box(graphic, 24, 29);
            logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

            logic.iTile[i] = new IT_Shelf(graphic, 35, 46);
            logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

            logic.iTile[i] = new IT_Shelf(graphic, 47, 23);
            logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

            logic.iTile[i] = new IT_Box(graphic, 45, 36);
            logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));
        } else {
            if (graphic.currentMap == 1){
                int i = 0;

                //SPAWN
                logic.iTile[i] = new IT_Box(graphic, 4, 13);
                logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

                logic.iTile[i] = new IT_Shelf(graphic, 11, 6);
                logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                //SECTOR A
                logic.iTile[i] = new IT_Box(graphic, 17, 12);
                logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

                //SECTOR B
                logic.iTile[i] = new IT_Shelf(graphic, 32, 17);
                logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                logic.iTile[i] = new IT_Box(graphic, 26, 34);
                logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

                //SECTOR D
                logic.iTile[i] = new IT_Shelf(graphic, 45, 46);
                logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                logic.iTile[i] = new IT_Shelf(graphic, 44, 5);
                logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                //SECTOR E
                logic.iTile[i] = new IT_Shelf(graphic, 4, 39);
                logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                logic.iTile[i] = new IT_Box(graphic, 17, 44);
                logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));
            } else {
                if (graphic.currentMap == 2){
                    int i = 0;

                    //SPAWN
                    logic.iTile[i] = new IT_Shelf(graphic, 22, 8);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                    logic.iTile[i] = new IT_Box(graphic, 11, 15);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

                    //SECTOR A
                    logic.iTile[i] = new IT_Box(graphic, 30, 15);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

                    logic.iTile[i] = new IT_Box(graphic, 25, 19);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

                    //SECTOR B
                    logic.iTile[i] = new IT_Box(graphic, 42, 9);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

                    logic.iTile[i] = new IT_Shelf(graphic, 47, 34);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                    //SECTOR C
                    logic.iTile[i] = new IT_Shelf(graphic, 11, 30);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                    logic.iTile[i] = new IT_Shelf(graphic, 47, 38);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                    //SECTOR D
                    logic.iTile[i] = new IT_Box(graphic, 27, 44);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));

                    logic.iTile[i] = new IT_Shelf(graphic, 13, 37);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                    //SECTOR E
                    logic.iTile[i] = new IT_Shelf(graphic, 5, 30);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Shelf_I.png"));

                    logic.iTile[i] = new IT_Box(graphic, 16, 24);
                    logic.iTile[i++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Boxes_I.png"));
                }
            }
        }


    }

    public void spawnWeapon() throws IOException{

        if (graphic.currentMap == 0){
            if (graphic.currentMap == 1 || graphic.currentMap == 2){
                logic.weapon = null;
            }
            int w = 0;

            //SPAWN
            logic.weapon[w] = new IT_Weapon(graphic, 8, 6);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            logic.weapon[w] = new IT_Weapon(graphic, 5, 14);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            //SECTOR A
            logic.weapon[w] = new IT_Weapon(graphic, 9, 32);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            logic.weapon[w] = new IT_Weapon(graphic, 5, 19);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            //SECTOR B
            logic.weapon[w] = new IT_Weapon(graphic, 19, 29);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            logic.weapon[w] = new IT_Weapon(graphic, 16, 45);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            //SECTOR C
            logic.weapon[w] = new IT_Weapon(graphic, 33, 20);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            logic.weapon[w] = new IT_Weapon(graphic, 34, 6);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            //SECTOR D
            logic.weapon[w] = new IT_Weapon(graphic, 42, 24);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            logic.weapon[w] = new IT_Weapon(graphic, 43, 7);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            //SECTOR E
            logic.weapon[w] = new IT_Weapon(graphic, 44, 45);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            logic.weapon[w] = new IT_Weapon(graphic, 42, 35);
            logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

        } else {
            if (graphic.currentMap == 1){
                int w = 0;

                //SPAWN
                logic.weapon[w] = new IT_Weapon(graphic, 6, 6);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 11, 10);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 8, 16);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 6, 22);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR A
                logic.weapon[w] = new IT_Weapon(graphic, 6, 34);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 15, 29);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 14, 17);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 19, 6);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR B
                logic.weapon[w] = new IT_Weapon(graphic, 25, 13);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 31, 11);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 21, 22);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 26, 33);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR C
                logic.weapon[w] = new IT_Weapon(graphic, 30, 21);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 40, 29);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 40, 44);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 31, 41);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 27, 37);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR D
                logic.weapon[w] = new IT_Weapon(graphic, 37, 14);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 43, 21);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 44, 6);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 46, 40);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR E
                logic.weapon[w] = new IT_Weapon(graphic, 9, 41);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 17, 37);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 21, 44);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

            } else {
                int w = 0;

                //SPAWN
                logic.weapon[w] = new IT_Weapon(graphic, 5, 17);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 11, 8);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 14, 16);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 20, 6);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 21, 12);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR A
                logic.weapon[w] = new IT_Weapon(graphic, 24, 9);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 25, 21);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 28, 11);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 30, 19);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 32, 13);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 34, 8);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR B
                logic.weapon[w] = new IT_Weapon(graphic, 39, 18);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 39, 34);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 40, 25);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 41, 7);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 44, 10);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 43, 14);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 45, 31);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR C
                logic.weapon[w] = new IT_Weapon(graphic, 32, 24);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 39, 39);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 46, 45);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 29, 30);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 24, 28);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 22, 31);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 12, 30);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR D
                logic.weapon[w] = new IT_Weapon(graphic, 30, 39);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 25, 37);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 23, 45);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 18, 43);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 12, 41);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                //SECTOR E
                logic.weapon[w] = new IT_Weapon(graphic, 20, 26);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 16, 20);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 9, 25);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 5, 29);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 9, 35);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));

                logic.weapon[w] = new IT_Weapon(graphic, 7, 41);
                logic.weapon[w++].tileInt[0].image = ImageIO.read(getClass().getResourceAsStream("/interactive_tile/Paper.png"));
            }
        }
    }
}
