package org.example.entity;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.IOException;

public class Enemy extends Entity{
    public int health;
    public boolean played = false;

    public Enemy(int x, int y, int health) {
        super(x, y);
        this.health = health;
        this.speed = 3;
        solidArea = new Rectangle(16, 32, 64, 64);

        getEnemyImage();
    }

    public void getEnemyImage(){
        try{
            up1 = ImageIO.read(getClass().getResourceAsStream("/enemy/Back1_S.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/enemy/Back2_S.png"));
            up3 = ImageIO.read(getClass().getResourceAsStream("/enemy/Back3_S.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/enemy/Front1_S.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/enemy/Front2_S.png"));
            down3 = ImageIO.read(getClass().getResourceAsStream("/enemy/Front3_S.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/enemy/Left1_S.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/enemy/Left2_S.png"));
            left3 = ImageIO.read(getClass().getResourceAsStream("/enemy/Left3_S.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/enemy/Right1_S.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/enemy/Right2_S.png"));
            right3 = ImageIO.read(getClass().getResourceAsStream("/enemy/Right3_S.png"));

        }catch(IOException e){
            e.printStackTrace();
        }
    }
}