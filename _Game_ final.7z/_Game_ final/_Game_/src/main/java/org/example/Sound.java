package org.example;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.net.URL;

public class Sound {
    Clip clip;
    URL soundURL[] = new URL[12];

    public Sound(){
        soundURL[0] = getClass().getResource("/sound/AnotherOne.wav");
        soundURL[1] = getClass().getResource("/sound/Error.wav");
        soundURL[2] = getClass().getResource("/sound/Cave11.wav");
        soundURL[3] = getClass().getResource("/sound/SpiderHiss.wav");
        soundURL[4] = getClass().getResource("/sound/SpiderWalk.wav");
        soundURL[5] = getClass().getResource("/sound/Yipee.wav");
        soundURL[6] = getClass().getResource("/sound/HelloThere.wav");
        soundURL[7] = getClass().getResource("/sound/Pew.wav");
        soundURL[8] = getClass().getResource("/sound/Punch.wav");
        soundURL[9] = getClass().getResource("/sound/Rizz.wav");
        soundURL[10] = getClass().getResource("/sound/Swoosh.wav");
        soundURL[11] = getClass().getResource("/sound/UndertakerBell.wav");
    }

    public void setFile(int i){
        try {
            AudioInputStream ais = AudioSystem.getAudioInputStream(soundURL[i]);
            clip = AudioSystem.getClip();
            clip.open(ais);

        }catch (Exception e){

        }
    }
    public void play(){
        clip.start();
    }
    public void stop(){
        clip.stop();
    }
}
