package org.example;

import org.example.entity.Enemy;
import org.example.tile.CollisionCheck;

import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;

public class Panel extends Thread implements Runnable{
    GameGraphics graphic;
    Logic logic;
    Thread thread;
    int FPS = 60;
    public boolean upPressed, downPressed, leftPressed, rightPressed, ePressed, fPressed;

    public Panel() {
        logic = new Logic(this);
        graphic = logic.graphic;
        logic.setGraphics(graphic);
        graphic.setFocusable(true);
        logic.initialize();

        graphic.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {

                int code = e.getKeyCode();

                if (logic.gameState == logic.menu){
                    if (code == KeyEvent.VK_W){
                        graphic.commandNum--;
                        if (graphic.commandNum < 0){
                            graphic.commandNum = 2;
                        }
                    }
                    if (code == KeyEvent.VK_S){
                        graphic.commandNum++;
                        if (graphic.commandNum > 2){
                            graphic.commandNum = 0;
                        }
                    }
                    if (code == KeyEvent.VK_ENTER){
                        if (graphic.commandNum == 0){
                            graphic.currentMap = 0;
                            logic.cCheck = new CollisionCheck(graphic, logic.tileCheck);
                            logic.projectileList.clear();
                            logic.entities.clear();
                            logic.player.setDefault();
                            logic.point = 0;
                            logic.weaponCount = 0;
                            try {
                                logic.AS.spawnWeapon();
                                logic.AS.setITile();
                            } catch (IOException ex) {
                                throw new RuntimeException(ex);
                            }
                            logic.gameState = logic.play;

                        }
                        if (graphic.commandNum == 1){
                            logic.loadCurrentLevel();
                            if (logic.level == 1){
                                logic.cCheck = new CollisionCheck(graphic, logic.tileCheck);
                                logic.projectileList.clear();
                                logic.entities.clear();
                                logic.player.setDefault();
                                logic.point = 0;
                                logic.weaponCount = 0;
                                try {
                                    logic.AS.spawnWeapon();
                                    logic.AS.setITile();
                                } catch (IOException ex) {
                                    throw new RuntimeException(ex);
                                }
                                logic.gameState = logic.play;
                            } else {
                                if (logic.level == 2){
                                    graphic.currentMap = 1;
                                    logic.cCheck = new CollisionCheck(graphic, logic.tileCheck);
                                    logic.projectileList.clear();
                                    logic.entities.clear();
                                    logic.player.setDefault();
                                    logic.point = 0;
                                    logic.weaponCount = 0;
                                    try {
                                        logic.AS.spawnWeapon();
                                        logic.AS.setITile();
                                    } catch (IOException ex) {
                                        throw new RuntimeException(ex);
                                    }
                                    logic.gameState = logic.play;
                                } else {
                                    graphic.currentMap = 2;
                                    logic.cCheck = new CollisionCheck(graphic, logic.tileCheck);
                                    logic.projectileList.clear();
                                    logic.entities.clear();
                                    logic.player.setDefault();
                                    logic.point = 0;
                                    logic.weaponCount = 0;
                                    try {
                                        logic.AS.spawnWeapon();
                                        logic.AS.setITile();
                                    } catch (IOException ex) {
                                        throw new RuntimeException(ex);
                                    }
                                    logic.gameState = logic.play;
                                }
                            }
                        }
                        if (graphic.commandNum == 2){
                            logic.gameState = logic.tutorial;
                            graphic.nextPage++;
                        }
                    }
                }

                if (logic.gameState == logic.tutorial){
                    if (code == KeyEvent.VK_A){
                        graphic.nextPage--;
                        if (graphic.nextPage == 0){
                            logic.gameState = logic.menu;
                        }

                    }
                    if (code == KeyEvent.VK_D){
                        if (graphic.nextPage < 4){
                            graphic.nextPage++;
                        }

                    }
                    if (code == KeyEvent.VK_ENTER){
                        if (graphic.nextPage == 4){
                            logic.gameState = logic.play;
                        }
                    }
                }
                if (logic.gameState == logic.end){
                    if (code == KeyEvent.VK_W){
                        graphic.commandNum--;
                        if (graphic.commandNum < 1){
                            graphic.commandNum = 2;
                        }
                    }
                    if (code == KeyEvent.VK_S){
                        graphic.commandNum++;
                        if (graphic.commandNum > 2){
                            graphic.commandNum = 1;
                        }
                    }
                    if (code == KeyEvent.VK_ENTER){
                        if (graphic.commandNum == 1){
                            logic.gameState = logic.menu;
                        }
                        if (graphic.commandNum == 2){
                            System.exit(0);
                        }
                    }
                }

                if (logic.gameState == logic.play){
                    if (code == KeyEvent.VK_W){
                        upPressed = true;
                    }
                    if (code == KeyEvent.VK_S){
                        downPressed = true;
                    }
                    if (code == KeyEvent.VK_A){
                        leftPressed = true;
                    }
                    if (code == KeyEvent.VK_D){
                        rightPressed = true;
                    }
                    if (code == KeyEvent.VK_E){
                        ePressed = true;
                    }
                    if (code == KeyEvent.VK_F){
                        fPressed = true;
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                int code = e.getKeyCode();
                if (code == KeyEvent.VK_W){
                    upPressed = false;
                }
                else if (code == KeyEvent.VK_S){
                    downPressed = false;
                }
                else if (code == KeyEvent.VK_A){
                    leftPressed = false;
                }
                else if (code == KeyEvent.VK_D){
                    rightPressed = false;
                }
                if (code == KeyEvent.VK_E){
                    ePressed = false;
                }
                if (code == KeyEvent.VK_F){
                    fPressed = false;
                }
            }
        });
    }

    public void startGameThread() throws IOException {
        logic.setUpGame();
        thread = new Thread(this);
        thread.start();
    }

    public void run() {
        double drawInterval = 1000000000/FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;

        while (thread != null){

            currentTime = System.nanoTime();
            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if (delta >= 1){
                try {
                    logic.update();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                graphic.render(logic);
                delta--;
                drawCount++;
            }
            if (timer>= 1000000000){
                System.out.println("FPS:" + drawCount);
                drawCount = 0;
                timer = 0;
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Panel panel = new Panel();
            try {
                panel.startGameThread();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        });
    }
}